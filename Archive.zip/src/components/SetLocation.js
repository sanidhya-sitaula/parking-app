import React from 'react'; 

import {GoogleMap, LoadScript, Marker, InfoWindow } from '@react-google-maps/api'; 


class MapContainer extends React.Component {

    handleOnClick(e){
        this.setState({lat: e.latLng.lat(), lng: e.latLng.lng()})
        this.props.setLatLng({'lat' : e.latLng.lat(), 'lng' : e.latLng.lng()})
    }

    state = {
        lat: this.props.lat? this.props.lat : null,
        lng : this.props.lng? this.props.lng : null,
        loading : true,
        selectedCenter : null
    };

    mapStyles = {
        height: this.props.height ? this.props.height : "500px",
        width: this.props.width ? this.props.width : "100%",
      };

      defaultCenter = {
        lat: this.props.lat ? this.props.lat : 27.7172,
        lng: this.props.lng ? this.props.lng : 85.3240,
      }

      render() {
          return (<LoadScript googleMapsApiKey="AIzaSyAQGsvrhfxDeNrqgubmm4G9xC1sBpS5xSg">
       
        <GoogleMap
          mapContainerStyle={this.mapStyles}
          zoom={this.props.address2 ? 10 : 13}
          center={{ lat: this.defaultCenter.lat, lng: this.defaultCenter.lng }}
          onClick = {this.props.lat && this.props.lng ? null : (e) => this.handleOnClick(e)}
        >
            {this.state.lat && this.state.lng? 
            <Marker 
                position = {{lat: this.state.lat, lng: this.state.lng}}
            /> : null}

            </GoogleMap>
            </LoadScript>
          )}
}

export default MapContainer; 