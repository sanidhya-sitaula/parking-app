import React from 'react'; 

import Card from './Card'; 

import {Grid} from '@material-ui/core'; 



const Stores = (props) => {
    const {stores} = props; 


    const displayStores = () => {
       return stores.map(store => {
            return (
            <>
                <Grid item xs = {4} key = {store.name}>
                    <Card title = {store.name} subheader = {store.address} description = {store.category.join(', ')} menu = {[store.email, store.phone]}/>
                </Grid>
            </>)
        })
    }

    return (
        <div className = "stores">
            <div className = "explore-message">
                <h1>You Can Explore</h1>
            </div>
            <Grid container spacing = {1}>
                {stores ? displayStores(): 'Loading Stores...'}
            </Grid>
        </div>
    )
}

export default Stores;