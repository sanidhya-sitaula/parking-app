import React from 'react'; 

const StoreProfile = (props) => {
    
}