import React from 'react'; 
import Navbar from './Navbar'; 
const Header = (props) => {
    const {title} = props; 
    const {userDetails, categories} = props; 
    return (
    <div className = "header">
        <Navbar userDetails = {userDetails} categories = {categories} />
        <div className = "header-message">
            {title}
        </div>
    </div>
    )
}

export default Header; 