import React, {useState} from 'react'; 
import MultipleSelect from './MultiSelect'; 

import TextField from "@mui/material/TextField";


const EditProfile = (props) => {
    const {userDetails, categories} = props; 
    const [category, setCategory] = useState();
    
    return (<>
    <div className="login-form2">
        <div className = "explore-message">
            <h1>Edit Your Profile</h1>
        </div>
        <ul className="login-form-items">
        <li>
            <TextField
              required
              id="outlined-required"
              label="Name"
              defaultValue={userDetails.name}
              style={{ width: "600px" }}
            />
          </li>
          <li>
            <TextField
                type = "password"
              required
              id="outlined-required"
              label="Password"
              defaultValue={userDetails.password}
              style={{ width: "600px" }}
            />
          </li>
          <li>
            <TextField
              required
              id="outlined-required"
              label="Phone"
              defaultValue={userDetails.phone}
              style={{ width: "600px" }}
            />
          </li>
          <li>
            {categories ? <div style = {{marginLeft : '-1%'}}><MultipleSelect categories = {categories} category = {category} setCategory = {setCategory} defaultCategories = {userDetails.category}/></div> : 'Loading..'}
          </li>
          <li>
            <TextField
              required
              id="outlined-required"
              label="Address"
              defaultValue={userDetails.address}
              style={{ width: "600px" }}
            />
          </li>
          
          <li>
              <button className = "submit-button2" onClick = {() => {}}>Edit Profile</button>
          </li>
        </ul>
      </div>
    </>)
    
}

export default EditProfile; 