import React, {useState} from "react";
import Header from "./Header";
import TextField from "@mui/material/TextField";
import {handleSignUp, handleSignup} from '../functions/index'; 
import { useNavigate } from 'react-router-dom'; 
import MultipleSelect from './MultiSelect'; 
const Signup = (props) => {

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState(''); 
  const [emailError, setEmailError] = useState();
  const [category, setCategory] = useState(''); 
  const [passwordError, setPasswordError] = useState(); 

  const {userDetails, categories} = props; 

  
  const navigate = useNavigate();

  const handleSubmit = async (name, address, phone, category, email, password, setEmailError, setPasswordError) => {
    await handleSignUp(name, address, phone, category, email, password, setEmailError, setPasswordError);
    navigate('/'); 
  }

  return (
    <>
      <Header title="Sign Up For A New Account" />
      <div className="login-form">
        <ul className="login-form-items">
        <li>
            <TextField
              required
              id="outlined-required"
              label="Name"
              defaultValue=""
              style={{ width: "600px" }}
              onChange = {e => setName(e.target.value)}
            />
          </li>
          <li>
            <TextField
              required
              id="outlined-required"
              label="Email"
              defaultValue=""
              style={{ width: "600px" }}
              onChange = {e => setEmail(e.target.value)}
            />
            {emailError ? <p>{emailError}</p>: null}
          </li>
          <li>
            <TextField
                type = "password"
              required
              id="outlined-required"
              label="Password"
              defaultValue=""
              style={{ width: "600px" }}
              onChange = {e => setPassword(e.target.value)}
            />
            {passwordError? <p>{passwordError}</p>: null}
          </li>
          <li>
            <TextField
              required
              id="outlined-required"
              label="Phone"
              defaultValue=""
              style={{ width: "600px" }}
              onChange = {e => setPhone(e.target.value)}
            />
          </li>
          <li>
            {categories ? <div style = {{marginLeft: '-1%'}}><MultipleSelect categories = {categories} category = {category} setCategory = {setCategory}/> </div>: 'Loading..'}
          </li>
          <li>
            <TextField
              required
              id="outlined-required"
              label="Address"
              defaultValue=""
              style={{ width: "600px" }}
              onChange = {e => setAddress(e.target.value)}
            />
          </li>
          
          <li>
              <button className = "submit-button" onClick = {() => handleSubmit(name, address, phone, category, email, password, setEmailError, setPasswordError)}>Sign Up</button>
          </li>
        </ul>
      </div>
    </>
  );
};

export default Signup;
