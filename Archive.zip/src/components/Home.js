import React, {useState, useEffect} from 'react'; 
import Header from './Header'; 
import Stores from './Stores'; 

const Home = (props) => {

    const {userDetails, loading, categories, stores} = props; 

    const [userLocation, setUserLocation] = useState();


    return (
        <>
        {loading? 'Loading...' : 
        <><Header userDetails = {userDetails} title = "Store Finder" categories = {categories}/>
        <Stores stores = {stores} /></>}
       
        </>
    )
}

export default Home; 