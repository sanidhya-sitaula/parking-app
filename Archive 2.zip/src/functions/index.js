import fire from "../fire";

// fire.firestore() => Access Firebase Database
const db = fire.firestore();

export const getAllStores = async (setStores) => {
  const stores = await db.collection(`/users/`).get();
  // React specific -- (React Hooks)
  setStores(stores.docs.map((doc) => doc.data()));
};

export const setFeaturedCollection = async (email, featuredCollection) => {
  await db.doc(`/users/${email}`).update({ featured: featuredCollection });
};

export const getUserDetails = (email, setUserDetails) => {
  db.doc(`/users/${email}`)
    .get()
    .then((doc) => setUserDetails(doc.data()));
};

export const getCategories = async (setCategories) => {
  const categories = await db.collection("/categories/").get();
  setCategories(categories.docs.map((doc) => doc.data()));
};

export const handleSetLocation = (email, latlng) => {
  db.doc(`/users/${email}`).update({ lat: latlng.lat, lng: latlng.lng });
};

export const handleEditProfile = (email, editedDetails) => {
  db.doc(`/users/${email}`).update({name : editedDetails.name, address : editedDetails.address, phone: editedDetails.phone, category : editedDetails.category})
}

export const handleLogin = (
  email,
  password,
  setEmailError,
  setPasswordError,
  setLoading
) => {
  fire
    .auth()
    .signInWithEmailAndPassword(email, password)
    .catch((err) => {
      switch (err.code) {
        case "auth/invalid-email":
        case "auth/user-disabled":
        case "auth/user-not-found":
          setEmailError(err.message);
          break;
        case "auth/wrong-password":
          setPasswordError(err.message);
          break;
      }
    })
    .then(setLoading(false));
};

export const handleSignUp = (
  name,
  address,
  phone,
  category,
  fileURL,
  email,
  password,
  setEmailError,
  setPasswordError
) => {
  fire
    .auth()
    .createUserWithEmailAndPassword(email, password)
    .catch((err) => {
      switch (err.code) {
        case "auth/email-already-in-use":
        case "auth/invalid-email":
          setEmailError(err.message);
          break;
        case "auth/weak-password":
          setPasswordError(err.message);
          break;
      }
    })
    .then((data) => {
      const userCredentials = {
        name: name,
        address: address,
        phone: phone,
        category: category,
        email: email,
        image: fileURL,
      };
      return db.doc(`/users/${email}`).set(userCredentials);
    });
};

export const handleLogout = () => {
  fire.auth().signOut();
};

export const authListener = (setLoading, setUserDetails) => {
  fire.auth().onAuthStateChanged((user) => {
    if (user) {
      getUserDetails(user.email, setUserDetails);
      setLoading(false);
    } else {
      setLoading(false);
    }
  });
};
