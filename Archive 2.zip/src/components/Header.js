import React from "react";
import Navbar from "./Navbar";
const Header = (props) => {
  const { title } = props;
  const { userDetails, categories, image } = props;
  let backgroundStyle;

  if (image) {
    backgroundStyle =
      `linear-gradient(rgba(0, 0, 0, 0.78), rgba(0, 0, 0, 0.78)), url(${image})`;
    
  } else {
    backgroundStyle = `linear-gradient(rgba(0, 0, 0, 0.78), rgba(0, 0, 0, 0.78)), url(https://firebasestorage.googleapis.com/v0/b/online-shopping-d370a.appspot.com/o/header.jpg?alt=media&token=cf1b4a61-4ae5-47b4-ac87-35df7c3955e1)`
  }
  return (
    <div
      className="header"
      style={{
        'background': backgroundStyle,
      }}
    >
      <Navbar userDetails={userDetails} categories={categories} />
      <div className="header-message">{title}</div>
    </div>
  );
};

export default Header;
