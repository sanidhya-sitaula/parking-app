import firebase from 'firebase'
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// Connect To Firebase Database

const firebaseConfig = {
  apiKey: "AIzaSyC9eb5O8op34HZ7ZqJvWo2wm5dMitVhtSw",
  authDomain: "online-shopping-d370a.firebaseapp.com",
  projectId: "online-shopping-d370a",
  storageBucket: "online-shopping-d370a.appspot.com",
  messagingSenderId: "669043807918",
  appId: "1:669043807918:web:7fc6df010216cec5e9ff3f"
};

// Initialize Firebase
const fire = firebase.initializeApp(firebaseConfig);

export default fire; 