import React, { useState, useEffect } from "react";
import Header from "./Header";
import Stores from "./Stores";
import { getDistance } from "geolib";
import BrowseCategory from "./BrowseCategory";

const Home = (props) => {
  const { userDetails, loading, categories, stores, userLocation } = props;

  const convertDistanceToKilometers = (distanceInMeters) => {
    return (distanceInMeters * 0.001).toFixed(2);
  };

  const getDistancesToStores = (stores) => {
    // User's Location
    const userLoc = {
      latitude: userLocation.lat,
      longitude: userLocation.lng,
    };
    // First, get distance to each store
    stores.map((store) => {
      if (store.lat && store.lng) {
        let storeLoc = {
          latitude: store.lat,
          longitude: store.lng,
        };
        let distance = getDistance(userLoc, storeLoc, 1);
        store["distance_from_user"] =
          convertDistanceToKilometers(distance)
            .toString()
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",") + " km";
      }
    });
  };

  return (
    <>
      {loading ? (
        "Loading..."
      ) : (
        <>
          <Header
            userDetails={userDetails}
            title="Store Finder"
            categories={categories}
          />

          {userLocation ? getDistancesToStores(stores) : null}
          <Stores stores={stores} />
          <BrowseCategory stores={stores} categories={categories} />
        </>
      )}
    </>
  );
};

export default Home;
