import logo from "./logo.svg";
import "./App.css";
import Header from "./components/Header";
import Stores from "./components/Stores";
import About from "./components/About";
import Home from "./components/Home";
import Login from "./components/Login";
import Signup from "./components/Signup";
import StoreProfile from "./components/StoreProfile";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  withRouter,
} from "react-router-dom";
import React, { useState, useEffect } from "react";
import { authListener, getCategories, getAllStores } from "./functions/index";
import StoreHome from "./components/StoreHome";

function App() {
  const [userDetails, setUserDetails] = useState();
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState();
  const [userLocation, setUserLocation] = useState();
  const [stores, setStores] = useState();

  useEffect(async () => {
    await authListener(setLoading, setUserDetails);
    await getAllStores(setStores);
    await getCategories(setCategories);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) =>
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        })
      );
    } else {
      alert("Geolocation not supported");
    }
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <Router>
          <Routes>
            {userDetails ? (
              <Route
                exact
                path="/"
                element={
                  <StoreHome
                    userDetails={userDetails}
                    loading={loading}
                    categories={categories}
                    setUserDetails={setUserDetails}
                  />
                }
              />
            ) : (
              <Route
                exact
                path="/"
                element={
                  <Home
                    userDetails={userDetails}
                    loading={loading}
                    categories={categories}
                    stores={stores}
                    userLocation={userLocation}
                  />
                }
              />
            )}

            <Route
              path="/about"
              element={<About userDetails={userDetails} />}
            />
            <Route
              path="/login"
              element={<Login userDetails={userDetails} />}
            />
            {categories ? (
              <Route
                path="/signup"
                element={
                  <Signup userDetails={userDetails} categories={categories} />
                }
              />
            ) : null}
            <Route
              path="/profile/:id"
              element={<StoreProfile userLocation={userLocation} />}
            />
          </Routes>
        </Router>
      </header>
    </div>
  );
}

export default App;
